<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penitipan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (empty($this->session->userdata('id'))) {
            redirect('admin/login');
        }

        //memanggil model
        $this->load->model(array('penitipan_model', 'admin_model', 'pelanggan_model', 'ras_kucing_model', 'kucing_model', 'kandang_model'));
    }

    public function index()
    {
        //mengarahkan ke function read
        $this->read();
    }

    public function read()
    {
        $data_penitipan = $this->penitipan_model->read();

        //mengirim data ke view
        $output = array(
            'judul' => 'Daftar Penitipan',
            'theme_page' => 'penitipan_read',

            'data_penitipan' => $data_penitipan
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function rekap_penitipan()
    {
        $data_penitipan = $this->penitipan_model->read();

        $output = array(
            'judul' => 'Laporan Detail Penitipan',
            'theme_page' => 'laporan_penitipan_read',
            'data_penitipan' => $data_penitipan
        );

        $this->load->view('theme/index', $output);
    }

    // membuat function untuk mengirim data ke laporan_kandang_read
    public function rekap_kandang()
    {
        $data_kandang = $this->penitipan_model->laporan_kandang();

        $output = array(
            'judul' => 'Laporan Data Kandang',
            'theme_page' => 'laporan_kandang_read',

            'data_kandang' => $data_kandang,
        );

        $this->load->view('theme/index', $output);
    }

    public function rekap_tgl_penitipan()
    {
        $data_tgl_penitipan = $this->penitipan_model->laporan_tgl_penitipan();

        $output = array(
            'judul' => 'Laporan Data Tanggal Penitipan',
            'theme_page' => 'laporan_tgl_penitipan_read',

            'data_tgl_penitipan' => $data_tgl_penitipan,
        );

        $this->load->view('theme/index', $output);
    }

    public function rekap_ras_kucing()
    {
        $data_ras_kucing = $this->penitipan_model->laporan_ras_kucing();

        $output = array(
            'judul' => 'Laporan Data Ras Kucing',
            'theme_page' => 'laporan_ras_kucing_read',

            'data_ras_kucing' => $data_ras_kucing,
        );

        $this->load->view('theme/index', $output);
    }

    public function insert()
    {
        $data_admin = $this->admin_model->read();
        $data_pelanggan = $this->pelanggan_model->read();
        $data_ras_kucing = $this->ras_kucing_model->read();
        // $data_kucing = $this->kucing_model->read();
        $data_kandang = $this->kandang_model->read();
        // $data_harga = $this->harga_model->read();

        //mengirim data ke view
        $output = array(
            'judul' => 'Tambah Penitipan',
            'theme_page' => 'penitipan_insert',

            'data_admin' => $data_admin,
            'data_pelanggan' => $data_pelanggan,
            'data_ras_kucing' => $data_ras_kucing,
            // 'data_kucing' => $data_kucing,
            'data_kandang' => $data_kandang,
            // 'data_harga' => $data_harga,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function insert_submit()
    {
        //menangkap data input dari view
        $admin_id = $this->input->post('admin_id');
        $pelanggan_id = $this->input->post('pelanggan_id');
        $ras_id = $this->input->post('ras_id');
        // $kucing_id = $this->input->post('kucing_id');
        $kandang_id = $this->input->post('kandang_id');
        // $harga_id = $this->input->post('harga_id');
        $nama_kucing = $this->input->post('nama_kucing');
        $tgl_penitipan = $this->input->post('tgl_penitipan');
        $jangka_waktu = $this->input->post('jangka_waktu');
        $denda = $this->input->post('denda');
        $status = $this->input->post('status');


        //mengirim data ke model
        $input = array(
            'admin_id' => $admin_id,
            'pelanggan_id' => $pelanggan_id,
            'ras_id' => $ras_id,
            // 'kucing_id' => $kucing_id,
            'kandang_id' => $kandang_id,
            // 'harga_id' => $harga_id,
            'nama_kucing' => $nama_kucing,
            'tgl_penitipan' => $tgl_penitipan,
            'jangka_waktu' => $jangka_waktu,
            'denda' => $denda,
            'status' => $status,
        );

        // pengurangan jumlah kandang
        $data_kandang_single = $this->kandang_model->read_single($kandang_id);
        $kandang_update = $data_kandang_single['jumlah_kandang'] - 1;
        $data_kandang = $this->kandang_model->update(['jumlah_kandang' => $kandang_update], $kandang_id);

        $data_penitipan = $this->penitipan_model->insert($input);

        //mengembalikan halaman ke function read
        redirect('penitipan/read');
    }

    public function update()
    {
        //menangkap id data yg dipilih dari view (parameter get)
        $id = $this->uri->segment(3);

        $data_penitipan_single = $this->penitipan_model->read_single($id);

        $data_admin = $this->admin_model->read();
        $data_pelanggan = $this->pelanggan_model->read();
        $data_ras_kucing = $this->ras_kucing_model->read();
        // $data_kucing = $this->kucing_model->read();
        $data_kandang = $this->kandang_model->read();
        // $data_harga = $this->harga_model->read();

        //mengirim data ke view
        $output = array(
            'judul' => 'Ubah Penitipan',
            'theme_page' => 'penitipan_update',

            'data_penitipan_single' => $data_penitipan_single,

            'data_admin' => $data_admin,
            'data_pelanggan' => $data_pelanggan,
            'data_ras_kucing' => $data_ras_kucing,
            // 'data_kucing' => $data_kucing,
            'data_kandang' => $data_kandang,
            // 'data_harga' => $data_harga,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function update_submit()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        //menangkap data input dari view
        $admin_id = $this->input->post('admin_id');
        $pelanggan_id = $this->input->post('pelanggan_id');
        $ras_id = $this->input->post('ras_id');
        // $kucing_id = $this->input->post('kucing_id');
        $kandang_id = $this->input->post('kandang_id');
        // $harga_id = $this->input->post('harga_id');
        $nama_kucing = $this->input->post('nama_kucing');
        $tgl_penitipan = $this->input->post('tgl_penitipan');
        $jangka_waktu = $this->input->post('jangka_waktu');
        $denda = $this->input->post('denda');
        $status = $this->input->post('status');

        //mengirim data ke model
        $input = array(
            'admin_id' => $admin_id,
            'pelanggan_id' => $pelanggan_id,
            'ras_id' => $ras_id,
            // 'kucing_id' => $kucing_id,
            'kandang_id' => $kandang_id,
            // 'harga_id' => $harga_id,
            'nama_kucing' => $nama_kucing,
            'tgl_penitipan' => $tgl_penitipan,
            'jangka_waktu' => $jangka_waktu,
            'denda' => $denda,
            'status' => $status,
        );

        $this->penitipan_model->update($input, $id);

        //mengembalikan halaman ke function read
        redirect('penitipan/read');
    }

    public function delete()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        $data_penitipan_single = $this->penitipan_model->read_single($id);

        $data_kandang_single = $this->kandang_model->read_single($data_penitipan_single['kandang_id']);

        $kandang_update = $data_kandang_single['jumlah_kandang'] + 1;
        $data_kandang = $this->kandang_model->update(['jumlah_kandang' => $kandang_update], $data_penitipan_single['kandang_id']);

        $data_penitipan = $this->penitipan_model->delete($id);

        //mengembalikan halaman ke function read
        redirect('penitipan/read');
    }

    public function read_export()
    {
        $data_penitipan = $this->penitipan_model->read();

        $output = array(
            'judul' => 'Daftar Penitipan',

            'data_penitipan' => $data_penitipan
        );

        $this->load->view('penitipan_read_export', $output);
    }

    public function data_export()
    {
        $data_penitipan = $this->penitipan_model->read();

        $output = array(
            'judul' => 'Daftar Penitipan',

            'data_penitipan' => $data_penitipan
        );

        $this->load->view('penitipan_data_export', $output);
    }

    public function kandang_data_export()
    {
        $data_kandang = $this->penitipan_model->laporan_kandang();

        $output = array(
            'judul' => 'Laporan Data Kandang',

            'data_kandang' => $data_kandang
        );

        $this->load->view('laporan_kandang_data_export', $output);
    }

    public function tgl_penitipan_data_export()
    {
        $data_tgl_penitipan = $this->penitipan_model->laporan_tgl_penitipan();

        $output = array(
            'judul' => 'Laporan Data Tanggal Penitipan',

            'data_tgl_penitipan' => $data_tgl_penitipan
        );

        $this->load->view('laporan_tgl_penitipan_data_export', $output);
    }

    public function ras_kucing_data_export()
    {
        $data_ras_kucing = $this->penitipan_model->laporan_ras_kucing();

        $output = array(
            'judul' => 'Laporan Data Ras Kucing',

            'data_ras_kucing' => $data_ras_kucing
        );

        $this->load->view('laporan_ras_kucing_data_export', $output);
    }

    public function penitipan_data_export()
    {
        $data_penitipan = $this->penitipan_model->read();

        $output = array(
            'judul' => 'Laporan Detail Penitipan',

            'data_penitipan' => $data_penitipan
        );

        $this->load->view('laporan_penitipan_data_export', $output);
    }

    public function cetak_struk()
    {
        //menangkap id data yg dipilih dari view (parameter get)
        $id = $this->uri->segment(3);

        //function read berfungsi mengambil 1 data dari table fakultas sesuai id yg dipilih
        $data_penitipan_single = $this->penitipan_model->read_single($id);
        //$data_penitipan = $this->penitipan_model->read();

        //memanggil function read pada fakultas model
        //function read berfungsi mengambil/read data dari table fakultas di database

        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Daftar penitipan',

            //data fakultas dikirim ke view
            'data_penitipan_single' => $data_penitipan_single,
            //'data_penitipan' => $data_penitipan
        );

        $this->load->view('penitipan_data_struk', $output);
    }

    public function unggah()
    {
        $id = $this->uri->segment(3);

        $data_penitipan_single = $this->penitipan_model->read_single($id);

        $output = array(
            'judul' => 'Upload File',
            'theme_page' => 'penitipan_upload',
            'data_penitipan_single' => $data_penitipan_single
        );

        $this->load->view('theme/index', $output);
    }

    public function submit_upload()
    {

        //setting library upload
        $config['upload_path']          = './upload_folder/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['overwrite']            = TRUE;
        $config['max_size']             = 10000;
        $config['encrypt_name']         = TRUE;
        $this->load->library('upload', $config);

        //jika gagal upload
        if (!$this->upload->do_upload('foto_kucing')) {

            $id = $this->uri->segment(3);
            $data_penitipan_single = $this->penitipan_model->read_single($id);

            //respon alasan kenapa gagal upload
            $response = $this->upload->display_errors();

            //mengirim output ke view
            $output = array(
                'judul' => 'Upload File',
                'theme_page' => 'penitipan_upload',
                'response' => $response,
                'data_penitipan_single' => $data_penitipan_single
            );
            $this->load->view('theme/index', $output);

            //jika upload berhasil
        } else {
            $id = $this->uri->segment(3);

            //respon upload berhasil 
            $upload_data = $this->upload->data();
            $file_name = $upload_data['file_name'];

            //pesan berhasil (boleh dirubah)
            // $response = 'berhasil upload, nama file  : ' . $file_name;

            //mengirim output ke view
            $input = array(
                'foto_kucing' => $file_name
            );

            $data_penitipan = $this->penitipan_model->update($input, $id);
            redirect('penitipan/read');
        }
    }

    public function line()
    {
        $data_tgl_penitipan = $this->penitipan_model->laporan_tgl_penitipan();

        //mengirim data ke view
        $output = array(
            'judul' => 'Penitipan Line Chart',
            'theme_page' => 'penitipan_line_chart',
            'data_tgl_penitipan' => $data_tgl_penitipan
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function ras_kucing_column()
    {
        $data_ras_kucing = $this->penitipan_model->laporan_ras_kucing();

        //mengirim data ke view
        $output = array(
            'judul' => 'Ras Kucing Column Chart',
            'theme_page' => 'ras_kucing_chart_column',
            'data_ras_kucing' => $data_ras_kucing
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }
}
