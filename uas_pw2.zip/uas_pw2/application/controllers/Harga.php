<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class harga extends CI_Controller {

	public function __construct() {
        parent::__construct();

		if(empty($this->session->userdata('id'))) {
        	redirect('admin/login');
        }

		//memanggil model
        $this->load->model('harga_model');
    }

	public function index() {
		//mengarahkan ke function read
		$this->read();
	}

	public function read() {
		//memanggil function read pada fakultas model
		//function read berfungsi mengambil/read data dari table fakultas di database
		$data_harga = $this->harga_model->read();

		//mengirim data ke view
		$output = array(
						//memanggil view
						'judul' => 'Daftar Harga',
						'theme_page' => 'harga_read',

						//data fakultas dikirim ke view
						'data_harga' => $data_harga,
					);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert() {
		//mengirim data ke view
		$output = array(
						//memanggil view
						'judul' => 'Tambah Harga',
						'theme_page' => 'harga_insert',
					);
		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert_submit() {
		//menangkap data input dari view
		$harga = $this->input->post('harga');

		//mengirim data ke model
		$input = array(
						//format : nama field/kolom table => data input dari view
						'harga' => $harga,
					);
		
		//memanggil function insert pada fakultas model
		//function insert berfungsi menyimpan/create data ke table fakultas di database
		$data_harga = $this->harga_model->insert($input);
		
		//mengembalikan halaman ke function read
		redirect('harga/read');
	}

	public function update() {
		//menangkap id data yg dipilih dari view (parameter get)
		$id = $this->uri->segment(3);

		//function read berfungsi mengambil 1 data dari table fakultas sesuai id yg dipilih
		$data_harga_single = $this->harga_model->read_single($id);

		//mengirim data ke view
		$output = array(
						'judul' => 'Ubah Harga',
						'theme_page' => 'harga_update',

						//mengirim data fakultas yang dipilih ke view
						'data_harga_single' => $data_harga_single,
					);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function update_submit() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//menangkap data input dari view
		$harga = $this->input->post('harga');

		//mengirim data ke model
		$input = array(
						//format : nama field/kolom table => data input dari view
						'harga' => $harga,
					);

		//memanggil function insert pada fakultas model
		//function insert berfungsi menyimpan/create data ke table fakultas di database
		$data_harga = $this->harga_model->update($input, $id);

		//mengembalikan halaman ke function read
		redirect('harga/read');
	}

	public function delete() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//memanggil function delete pada fakultas model
		$data_harga = $this->harga_model->delete($id);

		//mengembalikan halaman ke function read
		redirect('harga/read');
	}

	public function read_export() {
		//memanggil function read pada fakultas model
		//function read berfungsi mengambil/read data dari table fakultas di database
		$data_harga = $this->harga_model->read();
	
		//mengirim data ke view
		$output = array(
						//memanggil view
						'judul' => 'Daftar Harga',

						//data fakultas dikirim ke view
						'data_harga' => $data_harga
					);

		//memanggil file view
		$this->load->view('harga_read_export', $output);
	}

	public function data_export() {
		//memanggil function read pada fakultas model
		//function read berfungsi mengambil/read data dari table fakultas di database
		$data_harga = $this->harga_model->read();
	
		//mengirim data ke view
		$output = array(
						//memanggil view
						'judul' => 'Daftar Harga',

						//data fakultas dikirim ke view
						'data_harga' => $data_harga
					);

		$this->load->view('harga_data_export', $output);
	}

    public function cetak_struk() {
        //menangkap id data yg dipilih dari view (parameter get)
		$id = $this->uri->segment(3);

		//function read berfungsi mengambil 1 data dari table fakultas sesuai id yg dipilih
		$data_harga_single = $this->harga_model->read_single($id);

		//memanggil function read pada fakultas model
		//function read berfungsi mengambil/read data dari table fakultas di database
		//$data_harga = $this->harga_model->read();
	
		//mengirim data ke view
		$output = array(
						//memanggil view
						'judul' => 'Daftar Harga',

						//data fakultas dikirim ke view
						'data_harga_single' => $data_harga_single
					);

		$this->load->view('harga_data_struk', $output);
	}
}