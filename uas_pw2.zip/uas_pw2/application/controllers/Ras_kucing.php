<?php
defined('BASEPATH') or exit('No direct script access allowed');

// fakultas -> ras_kucing
// fakultas_model -> ras_kucing_model
// data_fakultas -> data_ras_kucing
// data_fakultas_single -> data_ras_kucing_single

class ras_kucing extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if (empty($this->session->userdata('id'))) {
			redirect('admin/login');
		}

		//memanggil model
		$this->load->model('ras_kucing_model');
	}

	public function index()
	{
		//mengarahkan ke function read
		$this->read();
	}

	public function read()
	{
		//memanggil function read pada ras_kucing model
		//function read berfungsi mengambil/read data dari table ras_kucing di database
		$data_ras_kucing = $this->ras_kucing_model->read();

		//mengirim data ke view
		$output = array(
			//memanggil view
			'judul' => 'Daftar Ras Kucing',
			'theme_page' => 'ras_kucing_read',

			//data ras_kucing dikirim ke view
			'data_ras_kucing' => $data_ras_kucing,
		);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert()
	{
		//mengirim data ke view
		$output = array(
			//memanggil view
			'judul' => 'Tambah Ras Kucing',
			'theme_page' => 'ras_kucing_insert',
		);
		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert_submit()
	{
		//menangkap data input dari view
		$nama_ras = $this->input->post('nama_ras');
		$harga_ras = $this->input->post('harga_ras');

		//mengirim data ke model
		$input = array(
			//format : nama field/kolom table => data input dari view
			'nama_ras' => $nama_ras,
			'harga_ras' => $harga_ras
		);

		//memanggil function insert pada ras_kucing model
		//function insert berfungsi menyimpan/create data ke table ras_kucing di database
		$data_ras_kucing = $this->ras_kucing_model->insert($input);

		//mengembalikan halaman ke function read
		redirect('ras_kucing/read');
	}

	public function update()
	{
		//menangkap id data yg dipilih dari view (parameter get)
		$id = $this->uri->segment(3);

		//function read berfungsi mengambil 1 data dari table ras_kucing sesuai id yg dipilih
		$data_ras_kucing_single = $this->ras_kucing_model->read_single($id);

		//mengirim data ke view
		$output = array(
			'judul' => 'Ubah Ras Kucing',
			'theme_page' => 'ras_kucing_update',

			//mengirim data ras_kucing yang dipilih ke view
			'data_ras_kucing_single' => $data_ras_kucing_single,
		);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function update_submit()
	{
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//menangkap data input dari view
		$nama_ras = $this->input->post('nama_ras');
		$harga_ras = $this->input->post('harga_ras');

		//mengirim data ke model
		$input = array(
			//format : nama field/kolom table => data input dari view
			'nama_ras' => $nama_ras,
			'harga_ras' => $harga_ras
		);

		//memanggil function insert pada ras_kucing model
		//function insert berfungsi menyimpan/create data ke table ras_kucing di database
		$data_ras_kucing = $this->ras_kucing_model->update($input, $id);

		//mengembalikan halaman ke function read
		redirect('ras_kucing/read');
	}

	public function delete()
	{
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//memanggil function delete pada ras_kucing model
		$data_ras_kucing = $this->ras_kucing_model->delete($id);

		//mengembalikan halaman ke function read
		redirect('ras_kucing/read');
	}

	public function read_export()
	{
		//memanggil function read pada ras_kucing model
		//function read berfungsi mengambil/read data dari table ras_kucing di database
		$data_ras_kucing = $this->ras_kucing_model->read();

		//mengirim data ke view
		$output = array(
			//memanggil view
			'judul' => 'Daftar Ras Kucing',

			//data ras_kucing dikirim ke view
			'data_ras_kucing' => $data_ras_kucing
		);

		//memanggil file view
		$this->load->view('ras_kucing_read_export', $output);
	}

	public function data_export()
	{
		//memanggil function read pada ras_kucing model
		//function read berfungsi mengambil/read data dari table ras_kucing di database
		$data_ras_kucing = $this->ras_kucing_model->read();

		//mengirim data ke view
		$output = array(
			//memanggil view
			'judul' => 'Daftar ras Kucing',

			//data ras_kucing dikirim ke view
			'data_ras_kucing' => $data_ras_kucing
		);

		$this->load->view('ras_kucing_data_export', $output);
	}
}
