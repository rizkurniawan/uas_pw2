<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kandang extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (empty($this->session->userdata('id'))) {
            redirect('admin/login');
        }

        //memanggil model
        $this->load->model('kandang_model');
    }

    public function index()
    {
        //mengarahkan ke function read
        $this->read();
    }

    public function read()
    {
        $data_kandang = $this->kandang_model->read();

        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Daftar Kandang',
            'theme_page' => 'kandang_read',

            'data_kandang' => $data_kandang,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function insert()
    {
        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Tambah Kandang',
            'theme_page' => 'kandang_insert',
        );
        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function insert_submit()
    {
        //menangkap data input dari view
        $ukuran = $this->input->post('ukuran_kandang');
        $status = $this->input->post('status');
        $jml_kandang = $this->input->post('jumlah_kandang');

        //mengirim data ke model
        $input = array(
            //format : nama field/kolom table => data input dari view
            'ukuran_kandang' => $ukuran,
            'status' => $status,
            'jumlah_kandang' => $jml_kandang,
        );

        $data_kandang = $this->kandang_model->insert($input);

        //mengembalikan halaman ke function read
        redirect('kandang/read');
    }

    public function update()
    {
        //menangkap id data yg dipilih dari view (parameter get)
        $id = $this->uri->segment(3);

        $data_kandang_single = $this->kandang_model->read_single($id);

        //mengirim data ke view
        $output = array(
            'judul' => 'Ubah Kandang',
            'theme_page' => 'kandang_update',

            'data_kandang_single' => $data_kandang_single,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function update_submit()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        //menangkap data input dari view
        $ukuran = $this->input->post('ukuran_kandang');
        $status = $this->input->post('status');
        $jml_kandang = $this->input->post('jumlah_kandang');

        //mengirim data ke model
        $input = array(
            //format : nama field/kolom table => data input dari view
            'ukuran_kandang' => $ukuran,
            'status' => $status,
            'jumlah_kandang' => $jml_kandang,
        );

        $data_kandang = $this->kandang_model->update($input, $id);

        //mengembalikan halaman ke function read
        redirect('kandang/read');
    }

    public function delete()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        $data_kandang = $this->kandang_model->delete($id);

        //mengembalikan halaman ke function read
        redirect('kandang/read');
    }

    public function data_export()
    {
        $data_kandang = $this->kandang_model->read();

        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Daftar Kandang',
            'theme_page' => 'kandang_read_export',

            'data_pelanggan' => $data_kandang
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function column()
    {
        //memanggil function read pada kota model
        //function read berfungsi mengambil/read data dari table kota di database
        $data_kandang = $this->kandang_model->read();

        //mengirim data ke view
        $output = array(
            'judul' => 'Kandang Column Chart',
            'theme_page' => 'kandang_chart_column',
            'data_kandang' => $data_kandang
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }
}
