<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pelanggan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (empty($this->session->userdata('id'))) {
            redirect('admin/login');
        }

        //memanggil model
        $this->load->model('pelanggan_model');
    }

    public function index()
    {
        //mengarahkan ke function read
        $this->read();
    }

    public function read()
    {
        $data_pelanggan = $this->pelanggan_model->read();

        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Daftar Pelanggan',
            'theme_page' => 'pelanggan_read',

            'data_pelanggan' => $data_pelanggan,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function insert()
    {
        //mengirim data ke view
        $output = array(
            //memanggil view
            'judul' => 'Tambah Pelanggan',
            'theme_page' => 'pelanggan_insert',
        );
        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function insert_submit()
    {
        //menangkap data input dari view
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $no_telp = $this->input->post('no_telp');

        //mengirim data ke model
        $input = array(
            //format : nama field/kolom table => data input dari view
            'nama' => $nama,
            'alamat' => $alamat,
            'no_telp' => $no_telp,
        );

        $data_pelanggan = $this->pelanggan_model->insert($input);

        //mengembalikan halaman ke function read
        redirect('pelanggan/read');
    }

    public function update()
    {
        //menangkap id data yg dipilih dari view (parameter get)
        $id = $this->uri->segment(3);

        $data_pelanggan_single = $this->pelanggan_model->read_single($id);

        //mengirim data ke view
        $output = array(
            'judul' => 'Ubah Pelanggan',
            'theme_page' => 'pelanggan_update',

            'data_pelanggan_single' => $data_pelanggan_single,
        );

        //memanggil file view
        $this->load->view('theme/index', $output);
    }

    public function update_submit()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        //menangkap data input dari view
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $no_telp = $this->input->post('no_telp');

        //mengirim data ke model
        $input = array(
            //format : nama field/kolom table => data input dari view
            'nama' => $nama,
            'alamat' => $alamat,
            'no_telp' => $no_telp,
        );

        $data_pelanggan = $this->pelanggan_model->update($input, $id);

        //mengembalikan halaman ke function read
        redirect('pelanggan/read');
    }

    public function delete()
    {
        //menangkap id data yg dipilih dari view
        $id = $this->uri->segment(3);

        $data_pelanggan = $this->pelanggan_model->delete($id);

        //mengembalikan halaman ke function read
        redirect('pelanggan/read');
    }

	public function read_export() {
		$data_pelanggan = $this->pelanggan_model->read();
	
		$output = array(
						'judul' => 'Daftar Pelanggan',

						'data_pelanggan' => $data_pelanggan
					);

		$this->load->view('pelanggan_read_export', $output);
	}

    // public function data_export()
    // {
    //     $data_pelanggan = $this->pelanggan_model->read();

    //     //mengirim data ke view
    //     $output = array(
    //         //memanggil view
    //         'judul' => 'Daftar Pelanggan',
    //         'theme_page' => 'pelanggan_read_export',

    //         'data_pelanggan' => $data_pelanggan
    //     );

    //     //memanggil file view
    //     $this->load->view('theme/index', $output);
    // }

    public function data_export() {
		$data_pelanggan = $this->pelanggan_model->read();
	
		$output = array(
						'judul' => 'Daftar Pelanggan',

						'data_pelanggan' => $data_pelanggan
					);

		$this->load->view('pelanggan_data_export', $output);
	}
}
