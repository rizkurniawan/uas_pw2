<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// mahasiswa -> kucing

class kucing extends CI_Controller {

	public function __construct() {
        parent::__construct();

		if(empty($this->session->userdata('id'))) {
        	redirect('admin/login');
        }

        //memanggil model
        $this->load->model(array('kucing_model', 'ras_kucing_model'));
    }

	public function index() {
		//mengarahkan ke function read
		$this->read();
	}

	public function read() {
		//memanggil function read pada kucing model
		//function read berfungsi mengambil/read data dari table kucing di database
		$data_kucing = $this->kucing_model->read();

		//mengirim data ke view
		$output = array(
						'judul' => 'Daftar Kucing',
						'theme_page' => 'kucing_read',

						//data mahasiswa dikirim ke view
						'data_kucing' => $data_kucing
					);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert() {
		//mengambil daftar mahasiswa dari table mahasiswa
		$data_ras_kucing = $this->ras_kucing_model->read();

		//mengirim data ke view
		$output = array(
						'judul' => 'Tambah Kucing',
						'theme_page' => 'kucing_insert',

						//mengirim daftar mahasiswa ke view
						'data_ras_kucing' => $data_ras_kucing,
					);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function insert_submit() {
		//menangkap data input dari view
		//$nim = $this->input->post('nim');
		$ras_kucing_id = $this->input->post('ras_kucing_id');
		$nama_kucing = $this->input->post('nama_kucing');
		$jenis_kelamin = $this->input->post('jenis_kelamin');

		//mengirim data ke model
		$input = array(
						// 'nim' => $nim,
						'ras_kucing_id' => $ras_kucing_id,
						'nama_kucing' => $nama_kucing,
						'jenis_kelamin' => $jenis_kelamin,
					);

		//memanggil function insert pada mahasiswa model
		//function insert berfungsi menyimpan/create data ke table mahasiswa di database
		$data_kucing = $this->kucing_model->insert($input);

		//mengembalikan halaman ke function read
		redirect('kucing/read');
	}

	public function update() {
		//menangkap id data yg dipilih dari view (parameter get)
		$id = $this->uri->segment(3);
		
		//function read berfungsi mengambil 1 data dari table mahasiswa sesuai id yg dipilih
		$data_kucing_single = $this->kucing_model->read_single($id);

		//mengambil daftar fakultas dari table fakultas
		$data_ras_kucing = $this->ras_kucing_model->read();

		//mengirim data ke view
		$output = array(
						'judul' => 'Ubah Kucing',
						'theme_page' => 'kucing_update',

						//mengirim data mahasiswa yang dipilih ke view
						'data_kucing_single' => $data_kucing_single,

						//mengirim daftar fakultas ke view
						'data_ras_kucing' => $data_ras_kucing,
					);

		//memanggil file view
		$this->load->view('theme/index', $output);
	}

	public function update_submit() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//menangkap data input dari view
		// $nim = $this->input->post('nim');
		$ras_kucing_id = $this->input->post('ras_kucing_id');
		$nama_kucing = $this->input->post('nama_kucing');
		$jenis_kelamin = $this->input->post('jenis_kelamin');

		//mengirim data ke model
		$input = array(
						// 'nim' => $nim,
						'ras_kucing_id' => $ras_kucing_id,
						'nama_kucing' => $nama_kucing,
						'jenis_kelamin' => $jenis_kelamin,
					);

		//memanggil function update pada mahasiswa model
		//function update berfungsi merubah data ke table mahasiswa di database
		$data_kucing = $this->kucing_model->update($input, $id);

		//mengembalikan halaman ke function read
		redirect('kucing/read');
	}

	public function delete() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//memanggil function delete pada mahasiswa model
		$data_kucing = $this->kucing_model->delete($id);

		//mengembalikan halaman ke function read
		redirect('kucing/read');
	}

	public function read_export() {
		$data_kucing = $this->kucing_model->read();
	
		$output = array(
						'judul' => 'Daftar Kucing',

						'data_kucing' => $data_kucing
					);

		$this->load->view('kucing_read_export', $output);
	}

	public function data_export() {
		$data_kucing = $this->kucing_model->read();
	
		$output = array(
						'judul' => 'Daftar Kucing',

						'data_kucing' => $data_kucing
					);

		$this->load->view('kucing_data_export', $output);
	}
}