<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penitipan_model extends CI_Model
{

    public function read()
    {

        //sql read
        $this->db->select('penitipan.*');
        $this->db->select(
            'admin.nama AS nama_admin, pelanggan.nama AS nama_pelanggan, 
            kandang.ukuran_kandang AS ukuran_kandang, kandang.harga_kandang AS harga_kandang,
            ras_kucing.harga_ras AS biaya, ras_kucing.nama_ras AS nama_ras'
        );
        $this->db->from('penitipan');
        $this->db->join('admin', 'penitipan.admin_id = admin.id');
        $this->db->join('pelanggan', 'penitipan.pelanggan_id = pelanggan.id');
        $this->db->join('ras_kucing', 'penitipan.ras_id = ras_kucing.id');
        // $this->db->join('kucing', 'penitipan.kucing_id = kucing.id');
        $this->db->join('kandang', 'penitipan.kandang_id = kandang.id');
        // $this->db->join('harga', 'penitipan.harga_id = harga.id');

        $this->db->order_by('penitipan.tgl_penitipan ASC');

        $query = $this->db->get();

        //$query->result_array = mengirim data ke controller dalam bentuk semua data
        return $query->result_array();
    }

    public function laporan_kandang()
    {
        $this->db->select('kandang.ukuran_kandang AS ukuran_kandang');
        $this->db->select('COUNT(kandang.jumlah_kandang) AS jml_kandang_sewa');
        $this->db->select('kandang.jumlah_kandang AS kandang_tersisa');
        $this->db->from('penitipan');
        $this->db->join('kandang', 'penitipan.kandang_id = kandang.id');
        $this->db->group_by('kandang.ukuran_kandang');

        $query = $this->db->get();

        return $query->result_array();
    }

    public function laporan_tgl_penitipan()
    {
        $this->db->select('*');
        $this->db->from('penitipan');
        $this->db->select('COUNT(penitipan.tgl_penitipan) AS jml_tgl_nitip');
        $this->db->group_by('penitipan.tgl_penitipan');

        $query = $this->db->get();

        return $query->result_array();
    }

    public function laporan_ras_kucing()
    {
        $this->db->select('ras_kucing.nama_ras AS nama_ras');
        $this->db->select('COUNT(penitipan.ras_id) AS jml_ras');
        $this->db->from('penitipan');
        $this->db->join('ras_kucing', 'penitipan.ras_id = ras_kucing.id');
        $this->db->group_by('ras_kucing.nama_ras');

        $query = $this->db->get();

        return $query->result_array();
    }

    public function read_single($id)
    {

        //sql read
        $this->db->select('*');
        $this->db->from('penitipan');

        $this->db->where('id', $id);

        $query = $this->db->get();

        //query->row_array = mengirim data ke controller dalam bentuk 1 data
        return $query->row_array();
    }

    public function insert($input)
    {
        //$input = data yang dikirim dari controller
        return $this->db->insert('penitipan', $input);
    }

    public function update($input, $id)
    {
        //$id = id data yang dikirim dari controller (sebagai filter data yang diubah)
        //filter data sesuai id yang dikirim dari controller
        $this->db->where('id', $id);

        //$input = data yang dikirim dari controller
        return $this->db->update('penitipan', $input);
    }

    //function delete berfungsi menghapus data dari table peminjaman buku di database
    public function delete($id)
    {
        //$id = id data yang dikirim dari controller (sebagai filter data yang dihapus)
        $this->db->where('id', $id);
        return $this->db->delete('penitipan');
    }
}
