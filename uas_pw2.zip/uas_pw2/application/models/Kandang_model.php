<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kandang_model extends CI_Model
{

    public function read()
    {

        //sql read
        $this->db->select('*');
        $this->db->from('kandang');
        $query = $this->db->get();

        //$query->result_array = mengirim data ke controller dalam bentuk semua data
        return $query->result_array();
    }

    public function read_single($id)
    {

        //sql read
        $this->db->select('*');
        $this->db->from('kandang');

        $this->db->where('id', $id);

        $query = $this->db->get();

        //query->row_array = mengirim data ke controller dalam bentuk 1 data
        return $query->row_array();
    }

    public function insert($input)
    {
        //$input = data yang dikirim dari controller
        return $this->db->insert('kandang', $input);
    }

    public function update($input, $id)
    {
        $this->db->where('id', $id);

        //$input = data yang dikirim dari controller
        return $this->db->update('kandang', $input);
    }

    public function delete($id)
    {
        //$id = id data yang dikirim dari controller (sebagai filter data yang dihapus)
        $this->db->where('id', $id);
        return $this->db->delete('kandang');
    }
}
