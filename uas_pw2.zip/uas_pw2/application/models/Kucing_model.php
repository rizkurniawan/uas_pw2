<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kucing_model extends CI_Model {

	//function read berfungsi mengambil/read data dari table mahasiswa di database
	public function read($ras_kucing_id='') {

		//sql read
        $this->db->select('kucing.*');
        $this->db->select('ras_kucing.nama_ras AS ras_kucing_id');
        $this->db->from('kucing');
        $this->db->join('ras_kucing', 'kucing.ras_kucing_id = ras_kucing.id');

        //filter data sesuai id yang dikirim dari controller
		if($ras_kucing_id != '') {
			$this->db->where('kucing.ras_kucing_id', $ras_kucing_id);
		}

        $this->db->order_by('kucing.ras_kucing_id ASC, kucing.nama_kucing ASC');

		$query = $this->db->get();

		//$query->result_array = mengirim data ke controller dalam bentuk semua data
        return $query->result_array();
	}

	//function read berfungsi mengambil/read data dari table mahasiswa di database
	public function read_single($id) {

		//sql read
		$this->db->select('*');
		$this->db->from('kucing');

		//$nim = id data yang dikirim dari controller (sebagai filter data yang dipilih)
		//filter data sesuai id yang dikirim dari controller
		$this->db->where('id', $id);

		$query = $this->db->get();

		//query->row_array = mengirim data ke controller dalam bentuk 1 data
        return $query->row_array();
	}

	//function insert berfungsi menyimpan/create data ke table mahasiswa di database
	public function insert($input) {
		//$input = data yang dikirim dari controller
		return $this->db->insert('kucing', $input);
	}

	//function update berfungsi merubah data ke table mahasiswa di database
	public function update($input, $id) {
		//$nim = id data yang dikirim dari controller (sebagai filter data yang diubah)
		//filter data sesuai id yang dikirim dari controller
		$this->db->where('id', $id);

		//$input = data yang dikirim dari controller
		return $this->db->update('kucing', $input);
	}

	//function delete berfungsi menghapus data dari table mahasiswa di database
	public function delete($id) {
		//$nim = id data yang dikirim dari controller (sebagai filter data yang dihapus)
		$this->db->where('id', $id);
		return $this->db->delete('kucing');
	}
}