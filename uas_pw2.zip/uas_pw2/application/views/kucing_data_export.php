<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_kucing.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1">
	<thead>
		<tr>
			<th>ID</th>
			<th>Ras Kucing</th>
			<th>Nama Kucing</th>
			<th>Jenis Kelamin</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data_kucing as $kucing):?>
		<tr>
			<td><?php echo $kucing['id'];?></td>
			<td><?php echo $kucing['ras_kucing_id'];?></td>
			<td><?php echo $kucing['nama_kucing'];?></td>
			<td><?php echo $kucing['jenis_kelamin'];?></td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>