	<form method="post" action="<?php echo site_url('harga/update_submit/' . $data_harga_single['id']); ?>">
		<table class="table">
			<tr>
				<td>Harga</td>
				<td><input type="text" name="harga" value="<?php echo $data_harga_single['harga']; ?>" required="" class="form-control"></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
			</tr>
		</table>
	</form>
