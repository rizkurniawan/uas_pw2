<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_data_pelanggan.xls");
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1" cellspacing="0" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor Telepon</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data fakultas-->
        <?php foreach ($data_pelanggan as $pelanggan) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $pelanggan['id']; ?></td>
                <td><?php echo $pelanggan['nama']; ?></td>
                <td><?php echo $pelanggan['alamat']; ?></td>
                <td><?php echo $pelanggan['no_telp']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>