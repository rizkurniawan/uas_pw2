<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_laporan_detail_penitipan.xls");
?>

<table border="1">
    <thead>
        <tr>
            <th>Tanggal Penitipan</th>
            <th>Nama Pelanggan</th>
            <th>Nama Kucing</th>
            <th>Ras Kucing</th>
            <th>Ukuran Kandang</th>
            <th>Jangka Waktu</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_penitipan as $penitipan) : ?>
            <tr>
                <td><?php echo $penitipan['tgl_penitipan']; ?></td>
                <td><?php echo $penitipan['nama_pelanggan']; ?></td>
                <td><?php echo $penitipan['nama_kucing']; ?></td>
                <td><?php echo $penitipan['nama_ras']; ?></td>
                <td><?php echo $penitipan['ukuran_kandang']; ?></td>
                <td><?php echo $penitipan['jangka_waktu']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>