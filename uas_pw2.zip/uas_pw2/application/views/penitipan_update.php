<form method="post" action="<?php echo site_url('penitipan/update_submit/' . $data_penitipan_single['id']); ?>">
    <table class="table">
        <tr>
            <td>Nama Admin</td>
            <td>
                <select name="admin_id" class="form-control">
                    <?php foreach ($data_admin as $admin) : ?>
                        <?php if ($admin['id'] == $data_penitipan_single['admin_id']) : ?>
                            <option value="<?php echo $admin['id']; ?>" selected><?php echo $admin['nama']; ?></option>
                        <?php else : ?>
                            <option value="<?php echo $admin['id']; ?>"><?php echo $admin['nama_admin']; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Nama Pelanggan</td>
            <td>
                <select name="pelanggan_id" class="form-control">
                    <?php foreach ($data_pelanggan as $pelanggan) : ?>
                        <?php if ($pelanggan['id'] == $data_penitipan_single['pelanggan_id']) : ?>
                            <option value="<?php echo $pelanggan['id']; ?>" selected><?php echo $pelanggan['nama']; ?></option>
                        <?php else : ?>
                            <option value="<?php echo $pelanggan['id']; ?>"><?php echo $pelanggan['nama']; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Nama Kucing</td>
            <td><input type="text" name="nama_kucing" value="<?php echo $data_penitipan_single['nama_kucing']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Ras Kucing</td>
            <td>
                <select name="ras_id" class="form-control">
                    <?php foreach ($data_ras_kucing as $ras_kucing) : ?>
                        <?php if ($ras_kucing['id'] == $data_penitipan_single['ras_id']) : ?>
                            <option value="<?php echo $ras_kucing['id']; ?>" selected><?php echo $ras_kucing['nama_ras']; ?></option>
                        <?php else : ?>
                            <option value="<?php echo $ras_kucing['id']; ?>"><?php echo $ras_kucing['nama_ras']; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Ukuran Kandang</td>
            <td>
                <select name="kandang_id" class="form-control">
                    <?php foreach ($data_kandang as $kandang) : ?>
                        <?php if ($kandang['id'] == $data_penitipan_single['kandang_id']) : ?>
                            <option value="<?php echo $kandang['id']; ?>" selected><?php echo $kandang['ukuran_kandang']; ?></option>
                        <?php else : ?>
                            <option value="<?php echo $kandang['id']; ?>"><?php echo $kandang['ukuran_kandang']; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Tanggal Penitipan</td>
            <td>
                <input type="date" name="tgl_penitipan" value="<?php echo $data_penitipan_single['tgl_penitipan']; ?>" required="" class="form-control">
            </td>
        </tr>
        <tr>
            <td>Jangka Waktu</td>
            <td><input type="text" name="jangka_waktu" value="<?php echo $data_penitipan_single['jangka_waktu']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Denda</td>
            <td><input type="text" name="denda" value="<?php echo $data_penitipan_single['denda']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Status</td>
            <?php
            $checked1 = $data_penitipan_single['status'] == "Sudah diambil" ? "checked=\"\"" : "";
            $checked2 = $data_penitipan_single['status'] == "Belum diambil" ? "checked=\"\"" : "";
            ?>
            <td>
                <input type="radio" name="status" required="" class="" value="Sudah diambil" <?= $checked1; ?>>Sudah diambil
                <input type="radio" name="status" required="" class="" value="Belum diambil" <?= $checked2; ?>>Belum diambil
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>