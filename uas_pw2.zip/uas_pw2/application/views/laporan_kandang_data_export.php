<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_laporan_data_kandang.xls");
?>

<table border="1">
    <thead>
        <tr>
            <th>Ukuran Kandang</th>
            <th>Jumlah Kandang disewa</th>
            <th>Total Kandang Tersisa</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data fakultas-->
        <?php foreach ($data_kandang as $kandang) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $kandang['ukuran_kandang']; ?></td>
                <td><?php echo $kandang['jml_kandang_sewa']; ?></td>
                <td><?php echo $kandang['kandang_tersisa']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>