<form method="post" action="<?php echo site_url('kandang/update_submit/' . $data_kandang_single['id']); ?>">
    <table class="table">
        <tr>
            <td>Ukuran Kandang</td>
            <?php
            $centang1 = $data_kandang_single['ukuran_kandang'] == "Kecil" ? "checked=\"\"" : "";
            $centang2 = $data_kandang_single['ukuran_kandang'] == "Sedang" ? "checked=\"\"" : "";
            $centang3 = $data_kandang_single['ukuran_kandang'] == "Besar" ? "checked=\"\"" : "";
            ?>
            <td>
                <input type="radio" name="ukuran_kandang" required="" class="" value="Besar" <?= $centang3; ?>>Besar
                <input type="radio" name="ukuran_kandang" required="" class="" value="Sedang" <?= $centang2; ?>>Sedang
                <input type="radio" name="ukuran_kandang" required="" class="" value="Kecil" <?= $centang1; ?>>Kecil
            </td>
        </tr>
        <tr>
            <td>Status</td>
            <?php
            $checked1 = $data_kandang_single['status'] == "Tersedia" ? "checked=\"\"" : "";
            $checked2 = $data_kandang_single['status'] == "Tidak Tersedia" ? "checked=\"\"" : "";
            ?>
            <td>
                <input type="radio" name="status" required="" class="" value="Tersedia" <?= $checked1; ?>>Tersedia
                <input type="radio" name="status" required="" class="" value="Tidak Tersedia" <?= $checked2; ?>>Tidak Tersedia
            </td>
        </tr>
        <tr>
            <td>Jumlah Kandang</td>
            <td><input type="text" name="jumlah_kandang" value="<?php echo $data_kandang_single['jumlah_kandang']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>