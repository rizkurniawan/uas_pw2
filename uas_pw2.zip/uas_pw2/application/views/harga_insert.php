	<form method="post" action="<?php echo site_url('harga/insert_submit/'); ?>">
		<table class="table">
			<tr>
				<td>Harga</td>
				<td><input type="text" name="harga" value="" required="" class="form-control"></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
			</tr>
		</table>
	</form>