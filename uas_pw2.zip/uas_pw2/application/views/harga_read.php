<!--link tambah data-->
<a href="<?php echo site_url('harga/insert');?>" class="btn btn-primary">Tambah</a>
<br /><br />

<table class="table" id="datatables">
	<thead class="thead-dark">
		<tr>
			<th>ID</th>
			<th>Harga</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_harga as $harga):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $harga['id'];?></td>
			<td><?php echo $harga['harga'];?></td>
			<td>
				<!--link ubah data (menyertakan id per baris untuk dikirim ke controller)-->
				<a href="<?php echo site_url('harga/update/'.$harga['id']);?>" class="btn btn-primary">
				Ubah
				</a>

				<!--link hapus data (menyertakan id per baris untuk dikirim ke controller)-->
				<a href="<?php echo site_url('harga/delete/'.$harga['id']);?>" onClick="return confirm('Apakah anda yakin?')" class="btn btn-danger">
				Hapus
				</a>

                <!-- cetak struk -->
				<a href="<?php echo site_url('harga/cetak_struk/'.$harga['id']);?>" class="btn btn-success">
				Cetak Struk
				</a>
				
			</td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>

<br /><br />
<a href="<?php echo site_url('harga/read_export');?>" class="btn btn-primary">Read Export</a>