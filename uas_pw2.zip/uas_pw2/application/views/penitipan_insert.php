<form method="post" action="<?php echo site_url('penitipan/insert_submit/'); ?>">
    <table class="table">
        <tr>
            <td>Nama Admin</td>
            <td>
                <select name="admin_id" class="form-control">
                    <?php foreach ($data_admin as $admin) : ?>
                        <option value="<?php echo $admin['id']; ?>">
                            <?php echo $admin['nama']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Nama Pelanggan</td>
            <td>
                <select name="pelanggan_id" class="form-control">
                    <?php foreach ($data_pelanggan as $pelanggan) : ?>
                        <option value="<?php echo $pelanggan['id']; ?>">
                            <?php echo $pelanggan['nama']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Nama Kucing</td>
            <td><input type="text" name="nama_kucing" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Ras Kucing</td>
            <td>
                <select name="ras_id" class="form-control">
                    <?php foreach ($data_ras_kucing as $ras_kucing) : ?>
                        <option value="<?php echo $ras_kucing['id']; ?>">
                            <?php echo $ras_kucing['nama_ras']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Ukuran Kandang</td>
            <td>
                <select name="kandang_id" class="form-control">
                    <?php foreach ($data_kandang as $kandang) : ?>
                        <option value="<?php echo $kandang['id']; ?>">
                            <?php echo $kandang['ukuran_kandang']; ?>
                            - <?php echo number_format($kandang['harga_kandang']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Tanggal Penitipan</td>
            <td><input type="date" name="tgl_penitipan" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Jangka Waktu</td>
            <td><input type="text" name="jangka_waktu" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Denda</td>
            <td><input type="text" name="denda" value="0" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Status Penitipan</td>
            <td>
                <input type="radio" name="status" value="Sudah diambil" required="">Sudah diambil
                <input type="radio" name="status" value="Belum diambil" required="">Belum diambil
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>