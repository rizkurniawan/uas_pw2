<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Ukuran Kandang</th>
            <th>Jumlah Kandang disewa</th>
            <th>Total Kandang Tersisa</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_kandang as $kandang) : ?>
            <tr>
                <td><?php echo $kandang['ukuran_kandang']; ?></td>
                <td><?php echo $kandang['jml_kandang_sewa']; ?></td>
                <td><?php echo $kandang['kandang_tersisa']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>

<br /><br />
<a href="<?php echo site_url('penitipan/kandang_data_export'); ?>" class="btn btn-primary">Export</a>