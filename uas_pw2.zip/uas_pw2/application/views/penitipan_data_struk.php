<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_penitipan.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1" cellspacing="0" cellpadding="10">
	<thead>
		<tr>
			<th>ID</th>
			<!-- <th>Nama Admin</th>
			<th>Nama Pelanggan</th>
			<th>Nama Kucing</th>
			<th>Ukuran Kandang</th> -->
			<th>Tanggal Penitipan</th>
			<th>Jangka Waktu</th>
			<!-- <th>Biaya per hari</th>
			<th>Status Pengembalian</th>
			<th>Total Pembayaran</th> -->
		</tr>
	</thead>
    <tbody>
			<tr>
				<td><?php echo $data_penitipan_single['id']; ?></td>
				<td><?php echo $data_penitipan_single['tgl_penitipan']; ?></td>
				<td><?php echo $data_penitipan_single['jangka_waktu']; ?></td>
			</tr>
    </tbody>
</table>

<h3>Terima Kasih</h3>