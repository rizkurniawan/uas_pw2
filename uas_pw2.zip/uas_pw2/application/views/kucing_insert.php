	<form method="post" action="<?php echo site_url('kucing/insert_submit/'); ?>">
		<table class="table">
			<tr>
				<td>Ras Kucing</td>
				<td>
					<select name="ras_kucing_id" class="form-control">
						<?php foreach ($data_ras_kucing as $ras_kucing) : ?>
							<option value="<?php echo $ras_kucing['id']; ?>">
								<?php echo $ras_kucing['nama_ras']; ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Nama Kucing</td>
				<td><input type="text" name="nama_kucing" value="" required="" class="form-control"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>
					<input type="radio" name="jenis_kelamin" value="Jantan"> Jantan
					<input type="radio" name="jenis_kelamin" value="Betina"> Betina
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
			</tr>
		</table>
	</form>