<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_data_kandang.xls");
?>

<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Ukuran Kandang</th>
            <th>Status</th>
            <th>Jumlah Kandang</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data fakultas-->
        <?php foreach ($data_kandang as $kandang) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $kandang['id']; ?></td>
                <td><?php echo $kandang['ukuran_kandang']; ?></td>
                <td><?php echo $kandang['status']; ?></td>
                <td><?php echo $kandang['jumlah_kandang']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>