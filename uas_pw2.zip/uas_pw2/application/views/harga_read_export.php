<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1" cellspacing="0" cellspading="10">
	<thead>
		<tr>
			<th>ID</th>
			<th>Harga</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_harga as $harga):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $harga['id'];?></td>
			<td><?php echo $harga['harga'];?></td>
		<?php endforeach?>		
	</tbody>
</table>

<br /><br />
<a href="<?php echo site_url('harga/data_export');?>">Export Excel</a>
