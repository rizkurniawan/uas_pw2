<form method="post" action="<?php echo site_url('pelanggan/insert_submit/'); ?>">
    <table class="table">
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><input type="text" name="alamat" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Nomor Telepon</td>
            <td><input type="text" name="no_telp" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>