<!--link tambah data-->
<a href="<?php echo site_url('ras_kucing/insert');?>" class="btn btn-primary">Tambah</a>
<br /><br />

<table class="table" id="datatables">
	<thead class="thead-dark">
		<tr>
			<th>ID</th>
			<th>Nama Ras</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_ras_kucing as $ras_kucing):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $ras_kucing['id'];?></td>
			<td><?php echo $ras_kucing['nama_ras'];?></td>
			<td>
				<!--link ubah data (menyertakan id per baris untuk dikirim ke controller)-->
				<a href="<?php echo site_url('ras_kucing/update/'.$ras_kucing['id']);?>" class="btn btn-primary">
				Ubah
				</a>

				<!--link hapus data (menyertakan id per baris untuk dikirim ke controller)-->
				<a href="<?php echo site_url('ras_kucing/delete/'.$ras_kucing['id']);?>" onClick="return confirm('Apakah anda yakin?')" class="btn btn-danger">
				Hapus
				</a>
				
			</td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>

<br /><br />
<a href="<?php echo site_url('ras_kucing/read_export');?>" class="btn btn-primary">Read Export</a>