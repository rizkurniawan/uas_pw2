<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_laporan_data_ras_kucing.xls");
?>

<table border="1">
    <thead>
        <tr>
            <th>Nama Ras</th>
            <th>Jumlah Ras yang dititip</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data fakultas-->
        <?php foreach ($data_ras_kucing as $ras_kucing) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $ras_kucing['nama_ras']; ?></td>
                <td><?php echo $ras_kucing['jml_ras']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>