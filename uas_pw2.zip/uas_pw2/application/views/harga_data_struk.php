<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_harga.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1">
	<thead>
		<tr>
			<th>ID</th>
			<th>Harga</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><?php echo $data_harga_single['id'];?></td>
			<td><?php echo $data_harga_single['harga'];?></td>
		</tr>
	</tbody>
</table>

<h3>Terima Kasih</h3>