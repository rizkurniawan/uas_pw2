<a href="<?php echo site_url('kandang/insert'); ?>" class="btn btn-primary">Tambah</a>
<a href="<?php echo site_url('kandang/insert'); ?>" class="btn btn-primary">Laporan</a>
<br /><br />

<table class="table" id="datatables">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Ukuran Kandang</th>
            <th>Status</th>
            <th>Jumlah Kandang</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_kandang as $kandang) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $kandang['id']; ?></td>
                <td><?php echo $kandang['ukuran_kandang']; ?></td>
                <td><?php echo $kandang['status']; ?></td>
                <td><?php echo $kandang['jumlah_kandang']; ?></td>
                <td>
                    <!--link ubah data (menyertakan id per baris untuk dikirim ke controller)-->
                    <a href="<?php echo site_url('kandang/update/' . $kandang['id']); ?>" class="btn btn-primary">
                        Ubah
                    </a>

                    <!--link hapus data (menyertakan id per baris untuk dikirim ke controller)-->
                    <a href="<?php echo site_url('kandang/delete/' . $kandang['id']); ?>" onClick="return confirm('Apakah anda yakin?')" class="btn btn-danger">
                        Hapus
                    </a>

                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>

<br /><br />
<a href="<?php echo site_url('kandang/data_export'); ?>" class="btn btn-primary">Export Excel</a>