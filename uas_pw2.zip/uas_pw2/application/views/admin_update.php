<form method="post" action="<?php echo site_url('admin/update_submit/' . $read_data['id']); ?>">
    <table class="table">
        <tr>
            <td>Username</td>
            <td><input type="text" name="username" value="<?= $read_data['username']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" value="<?= $read_data['nama'] ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>