<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_penitipan.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1" cellspacing="0" cellpadding="10">
	<thead>
		<tr>
			<th>ID</th>
			<th>Nama Admin</th>
			<th>Nama Pelanggan</th>
			<th>Nama Kucing</th>
			<th>Ukuran Kandang</th>
			<th>Tanggal Penitipan</th>
			<th>Jangka Waktu</th>
			<th>Biaya per hari</th>
			<th>Status Pengembalian</th>
			<th>Total Pembayaran</th>
		</tr>
	</thead>
    <tbody>
        <?php foreach ($data_penitipan as $penitipan) : ?>
            <tr>
                <td><?php echo $penitipan['id']; ?></td>
                <td><?php echo $penitipan['nama_admin']; ?></td>
				<td><?php echo $penitipan['nama_pelanggan']; ?></td>
				<td><?php echo $penitipan['nama_kucing']; ?></td>
				<td><?php echo $penitipan['ukuran_kandang']; ?></td>
				<td><?php echo $penitipan['tgl_penitipan']; ?></td>
				<td><?php echo $penitipan['jangka_waktu']; ?></td>
				<td><?php echo $penitipan['biaya']; ?></td>
				<td><?php echo $penitipan['status']; ?></td>
				<td><?php echo $penitipan['biaya'] * $penitipan['jangka_waktu']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>