<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Tanggal Penitipan</th>
            <th>Jumlah Penitipan</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_tgl_penitipan as $tgl_penitipan) : ?>
            <tr>
                <td><?php echo $tgl_penitipan['tgl_penitipan']; ?></td>
                <td><?php echo $tgl_penitipan['jml_tgl_nitip']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>

<br /><br />
<a href="<?php echo site_url('penitipan/tgl_penitipan_data_export'); ?>" class="btn btn-primary">Export</a>