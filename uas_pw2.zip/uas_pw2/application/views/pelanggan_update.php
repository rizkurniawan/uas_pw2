<form method="post" action="<?php echo site_url('pelanggan/update_submit/' . $data_pelanggan_single['id']); ?>">
    <table class="table">
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" value="<?php echo $data_pelanggan_single['nama']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><input type="text" name="alamat" value="<?php echo $data_pelanggan_single['alamat']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>Nomor Telepon</td>
            <td><input type="text" name="no_telp" value="<?php echo $data_pelanggan_single['no_telp']; ?>" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>