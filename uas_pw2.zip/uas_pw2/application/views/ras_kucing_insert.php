	<form method="post" action="<?php echo site_url('ras_kucing/insert_submit/'); ?>">
		<table class="table">
			<tr>
				<td>Nama Ras</td>
				<td><input type="text" name="nama_ras" value="" required="" class="form-control"></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
			</tr>
		</table>
	</form>