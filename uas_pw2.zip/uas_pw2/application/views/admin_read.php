<!--link tambah data-->
<a href="<?php echo site_url('admin/insert'); ?>" class="btn btn-primary">Tambah</a>
<br /><br />

<table class="table" id="datatables">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Username</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data provinsi-->
        <?php foreach ($data_admin as $admin) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $admin['id']; ?></td>
                <td><?php echo $admin['nama']; ?></td>
                <td><?php echo $admin['username']; ?></td>
                <td>
                    <!--link ubah data (menyertakan id per baris untuk dikirim ke controller)-->
                    <a href="<?php echo site_url('admin/update/' . $admin['id']); ?>" class="btn btn-primary">
                        Ubah Identitas
                    </a>

                    <a href="<?php echo site_url('admin/reset/' . $admin['id']); ?>" class="btn btn-warning">
                        Reset Password
                    </a>

                    <!--link hapus data (menyertakan id per baris untuk dikirim ke controller)-->
                    <a href="<?php echo site_url('admin/delete/' . $admin['id']); ?>" onClick="return confirm('Apakah anda yakin?')" class="btn btn-danger">
                        Hapus
                    </a>

                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>