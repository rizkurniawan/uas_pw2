	<form method="post" action="<?php echo site_url('kucing/update_submit/' . $data_kucing_single['id']); ?>">
		<table class="table">
			<tr>
				<td>Spesies Kucing</td>
				<td>
					<select name="ras_kucing_id" class="form-control">
						<?php foreach ($data_ras_kucing as $ras_kucing) : ?>
							<?php if ($ras_kucing['id'] == $data_kucing_single['ras_kucing_id']) : ?>
								<option value="<?php echo $ras_kucing['id']; ?>" selected><?php echo $ras_kucing['nama_ras']; ?></option>
							<?php else : ?>
								<option value="<?php echo $ras_kucing['id']; ?>"><?php echo $ras_kucing['nama_ras']; ?></option>
							<?php endif; ?>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Nama Kucing</td>
				<td><input type="text" name="nama_kucing" value="<?php echo $data_kucing_single['nama_kucing']; ?>" required="" class="form-control"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
                <?php
				$checked1 = $data_kucing_single['jenis_kelamin'] == "Jantan" ? "checked=\"\"" : "";
				$checked2 = $data_kucing_single['jenis_kelamin'] == "Betina" ? "checked=\"\"" : "";
				?>
				<td><input type="radio" name="jenis_kelamin" value="Jantan" <?= $checked1; ?>> Jantan
					<input type="radio" name="jenis_kelamin" value="Betina" <?= $checked2; ?>> Betina
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
			</tr>
		</table>
	</form>

</body>

</html>