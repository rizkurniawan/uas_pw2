<a href="<?php echo site_url('kucing/insert');?>" class="btn btn-primary">Tambah</a>
<br /><br />

<table class="table" id="datatables">
	<thead class="thead-dark">
		<tr>
			<th>ID</th>
			<th>Ras Kucing</th>
			<th>Nama Kucing</th>
			<th>Jenis Kelamin</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data_kucing as $kucing):?>
		<tr>
			<td><?php echo $kucing['id'];?></td>
			<td><?php echo $kucing['ras_kucing_id'];?></td>
			<td><?php echo $kucing['nama_kucing'];?></td>
			<td><?php echo $kucing['jenis_kelamin'];?></td>
			<td>
				<a href="<?php echo site_url('kucing/update/'.$kucing['id']);?>" class="btn btn-primary">
				Ubah
				</a>
				
				<a href="<?php echo site_url('kucing/delete/'.$kucing['id']);?>" class="btn btn-danger" onClick="return confirm('Apakah anda yakin?')">
				Hapus
				</a>
			</td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>

<br /><br />
<a href="<?php echo site_url('kucing/read_export');?>" class="btn btn-primary">Read Export</a>
