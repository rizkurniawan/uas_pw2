<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Tanggal Penitipan</th>
            <th>Nama Pelanggan</th>
            <th>Nama Kucing</th>
            <th>Ras Kucing</th>
            <th>Ukuran Kandang</th>
            <th>Jangka Waktu</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_penitipan as $penitipan) : ?>
            <tr>
                <td><?php echo $penitipan['tgl_penitipan']; ?></td>
                <td><?php echo $penitipan['nama_pelanggan']; ?></td>
                <td><?php echo $penitipan['nama_kucing']; ?></td>
                <td><?php echo $penitipan['nama_ras']; ?></td>
                <td><?php echo $penitipan['ukuran_kandang']; ?></td>
                <td><?php echo $penitipan['jangka_waktu']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>

<br>
<a href="<?php echo site_url('penitipan/penitipan_data_export'); ?>" class="btn btn-primary">Export</a>