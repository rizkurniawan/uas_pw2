<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-disposition: attachment; filename=export_laporan_data_tgl_penitipan.xls");
?>

<table border="1">
    <thead>
        <tr>
            <th>Tanggal Penitipan</th>
            <th>Jumlah Penitipan</th>
        </tr>
    </thead>
    <tbody>
        <!--looping data fakultas-->
        <?php foreach ($data_tgl_penitipan as $tgl_penitipan) : ?>

            <!--cetak data per baris-->
            <tr>
                <td><?php echo $tgl_penitipan['tgl_penitipan']; ?></td>
                <td><?php echo $tgl_penitipan['jml_tgl_nitip']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>