<form method="post" action="<?php echo site_url('kandang/insert_submit/'); ?>">
    <table class="table">
        <tr>
            <td>Ukuran Kandang</td>
            <td>
                <input type="radio" name="ukuran_kandang" value="Besar" required="" class="">Besar
                <input type="radio" name="ukuran_kandang" value="Sedang" required="" class="">Sedang
                <input type="radio" name="ukuran_kandang" value="Kecil" required="" class="">Kecil
            </td>
        </tr>
        <tr>
            <td>Status</td>
            <td>
                <input type="radio" name="status" value="Tersedia" required="" class="">Tersedia
                <input type="radio" name="status" value="Tidak Tersedia" required="" class="">Tidak Tersedia
            </td>
        </tr>
        <tr>
            <td>Jumlah Kandang</td>
            <td><input type="text" name="jumlah_kandang" value="" required="" class="form-control"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit" value="Simpan" class="btn btn-success"></td>
        </tr>
    </table>
</form>