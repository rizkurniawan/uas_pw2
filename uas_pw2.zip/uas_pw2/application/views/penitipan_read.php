<a href="<?php echo site_url('penitipan/insert'); ?>" class="btn btn-primary">Tambah</a>
<br /><br />

<table class="table">
	<thead class="thead-dark">
		<tr>
			<th>Tanggal Penitipan</th>
			<th>Nama Pelanggan</th>
			<th>Nama Kucing</th>
			<th>Ras Kucing</th>
			<th>Foto Kucing</th>
			<th>Ukuran Kandang</th>
			<th>Jangka Waktu</th>
			<th>Biaya per hari</th>
			<th>Harga Kandang</th>
			<th>Denda</th>
			<th>Status Pengembalian</th>
			<th>Total Pembayaran</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($data_penitipan as $penitipan) : ?>
			<tr>
				<td><?php echo $penitipan['tgl_penitipan']; ?></td>
				<td><?php echo $penitipan['nama_pelanggan']; ?></td>
				<td><?php echo $penitipan['nama_kucing']; ?></td>
				<td><?php echo $penitipan['nama_ras']; ?></td>

				<?php
				$gambar = base_url('./upload_folder/' . $penitipan['foto_kucing']);
				?>

				<!-- menampilkan gambar -->
				<td><img src="<?= $gambar ?>" height="100" width="100"></td>

				<td><?php echo $penitipan['ukuran_kandang']; ?></td>
				<td><?php echo $penitipan['jangka_waktu']; ?></td>
				<!-- biaya = harga ras kucing -->
				<td><?php echo number_format($penitipan['biaya']); ?></td>
				<td><?php echo number_format($penitipan['harga_kandang']); ?></td>
				<td><?php echo number_format($penitipan['denda']); ?></td>
				<td><?php echo $penitipan['status']; ?></td>
				<td><?php echo number_format(($penitipan['biaya'] + $penitipan['harga_kandang'] + $penitipan['denda']) * $penitipan['jangka_waktu']); ?></td>
				<td>
					<a href="<?php echo site_url('penitipan/update/' . $penitipan['id']); ?>" class="btn btn-primary">
						Ubah
					</a>

					<a href="<?php echo site_url('penitipan/delete/' . $penitipan['id']); ?>" class="btn btn-danger" onClick="return confirm('Apakah anda yakin?')">
						Hapus
					</a>

					<a href="<?php echo site_url('penitipan/unggah/' . $penitipan['id']); ?>" class="btn btn-info">
						Upload
					</a>

					<a href="<?php echo site_url('penitipan/cetak_struk/' . $penitipan['id']); ?>" class="btn btn-success">
						Cetak Struk
					</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>