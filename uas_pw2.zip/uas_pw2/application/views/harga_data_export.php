<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_fakultas.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1">
	<thead>
		<tr>
		<tr>
			<th>ID</th>
			<th>Harga</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_harga as $harga):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $harga['id'];?></td>
			<td><?php echo $harga['harga'];?></td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>