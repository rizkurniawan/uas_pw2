<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1" cellspacing="0" cellpadding="10">
	<thead>
		<tr>
			<th>ID</th>
			<th>Nama Ras</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_ras_kucing as $ras_kucing):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $ras_kucing['id'];?></td>
			<td><?php echo $ras_kucing['nama_ras'];?></td>
		<?php endforeach?>		
	</tbody>
</table>

<br /><br />
<a href="<?php echo site_url('ras_kucing/data_export');?>">Export Excel</a>
