<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Nama Ras Kucing</th>
            <th>Jumlah Ras yang dititip</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data_ras_kucing as $ras_kucing) : ?>
            <tr>
                <td><?php echo $ras_kucing['nama_ras']; ?></td>
                <td><?php echo $ras_kucing['jml_ras']; ?></td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>

<br /><br />
<a href="<?php echo site_url('penitipan/ras_kucing_data_export'); ?>" class="btn btn-primary">Export</a>