<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

  <!-- Sidebar - Brand -->
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
    <div class="sidebar-brand-icon rotate-n-15">
      <i class="fas fa-cat"></i>
    </div>
    <div class="sidebar-brand-text mx-3">Katt</div>
  </a>

  <!-- Divider -->
  <hr class="sidebar-divider my-0">

  <!-- Nav Item - Charts -->
  <li class="nav-item">
    <a class="nav-link" href="<?php echo site_url('ras_kucing/read'); ?>">
      <i class="fas fa-fw fa-cat"></i>
      <span>Ras Kucing</span></a>
  </li>

  <!-- Nav Item - Charts -->
  <!-- <li class="nav-item">
    <a class="nav-link" href="<?php //echo site_url('kucing/read'); 
                              ?>">
      <i class="fas fa-fw fa-cat"></i>
      <span>Kucing</span></a>
  </li> -->

  <!-- Nav Item - Charts -->
  <!-- <li class="nav-item">
    <a class="nav-link" href="<?php // echo site_url('harga/read'); 
                              ?>">
      <i class="fas fa fa-credit-card"></i>
      <span>Harga</span></a>
  </li> -->

  <!-- Nav Item - Charts -->
  <li class="nav-item">
    <a class="nav-link" href="<?php echo site_url('kandang/read'); ?>">
      <i class="fas fa fa-home"></i>
      <span>Kandang</span></a>
  </li>

  <!-- Nav Item - Charts -->
  <li class="nav-item">
    <a class="nav-link" href="<?php echo site_url('pelanggan/read'); ?>">
      <i class="fas fa fa-user"></i>
      <span>Pelanggan</span></a>
  </li>

  <!-- Nav Item - Charts -->
  <li class="nav-item">
    <a class="nav-link" href="<?php echo site_url('admin/read'); ?>">
      <i class="fas fa fa-user"></i>
      <span>Admin</span></a>
  </li>

  <!-- Nav Item - Charts -->
  <li class="nav-item">
    <a class="nav-link" href="<?php echo site_url('penitipan/read'); ?>">
      <i class="fas fa-clipboard-list"></i>
      <span>Penitipan</span></a>
  </li>

  <!-- Heading -->
  <!-- //TODO belum terpakai -->
  <!-- <div class="sidebar-heading">
    Addons
  </div> -->

  <!-- Nav Item - Pages Collapse Menu -->
  <!-- //TODO belum terpakai -->
  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
      <i class="fas fa-fw fa-folder"></i>
      <span>Pages</span>
    </a>
    <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <h6 class="collapse-header">Login Screens:</h6>
        <a class="collapse-item" href="login.html">Login</a>
        <a class="collapse-item" href="register.html">Register</a>
        <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
        <div class="collapse-divider"></div>
        <h6 class="collapse-header">Other Pages:</h6>
        <a class="collapse-item" href="404.html">404 Page</a>
        <a class="collapse-item" href="blank.html">Blank Page</a>
      </div>
    </div>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="#">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Charts</span></a>
  </li> -->

  <!--//TODO Nav Item - Chart -->
  <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Charts</span>
    </a>
    <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <h6 class="collapse-header">Column Chart :</h6>
        <a class="collapse-item" href="<?php echo site_url('kandang/column/'); ?>">Kandang</a>
        <a class="collapse-item" href="<?php echo site_url('penitipan/ras_kucing_column/'); ?>">Ras Kucing</a>
        <h6 class="collapse-header">Line Chart :</h6>
        <a class="collapse-item" href="<?php echo site_url('penitipan/line/'); ?>">Tanggal Penitipan</a>
      </div>
    </div>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1" aria-expanded="true" aria-controls="collapsePages1">
      <i class="fas fa-clipboard-list"></i>
      <span>Laporan</span>
    </a>
    <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <h6 class="collapse-header">Laporan Detail :</h6>
        <a class="collapse-item" href="<?php echo site_url('penitipan/rekap_penitipan/'); ?>">Laporan Penitipan</a>
        <h6 class="collapse-header">Laporan Rekap :</h6>
        <a class="collapse-item" href="<?php echo site_url('penitipan/rekap_kandang/'); ?>">Laporan Kandang</a>
        <a class="collapse-item" href="<?php echo site_url('penitipan/rekap_tgl_penitipan/'); ?>">Laporan Tanggal Penitipan</a>
        <a class="collapse-item" href="<?php echo site_url('penitipan/rekap_ras_kucing/'); ?>">Laporan Ras Kucing</a>
      </div>
    </div>
  </li>

  <hr class="sidebar-divider d-none d-md-block">

  <div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
  </div>

</ul>