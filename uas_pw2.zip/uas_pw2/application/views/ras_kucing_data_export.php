<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_ras_kucing.xls" );
?>

<h1>JRM Cat House</h1>
<p>Tanggal : <?= date("d M Y"); ?> </p>

<table border="1">
	<thead>
		<tr>
			<th>ID</th>
			<th>Nama Ras</th>
		</tr>
	</thead>
	<tbody>
		<!--looping data fakultas-->
		<?php foreach($data_ras_kucing as $ras_kucing):?>

		<!--cetak data per baris-->
		<tr>
			<td><?php echo $ras_kucing['id'];?></td>
			<td><?php echo $ras_kucing['nama_ras'];?></td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>